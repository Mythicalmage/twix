from django.apps import AppConfig


class RightConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'right'
