from django.contrib import admin
from .models import ProductRight
from left.models import Category
# Register your models here.
admin.site.register(ProductRight)
admin.site.register(Category)
